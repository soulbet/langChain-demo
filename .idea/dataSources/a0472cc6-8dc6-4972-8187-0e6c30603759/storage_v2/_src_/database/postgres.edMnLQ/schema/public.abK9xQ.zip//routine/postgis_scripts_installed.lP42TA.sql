create function postgis_scripts_installed() returns text
    immutable
    language sql
as
$$ SELECT trim('3.6.4'::text || $rev$ 94d984b $rev$) AS version $$;

alter function postgis_scripts_installed() owner to postgres;

