create function postgis_scripts_build_date() returns text
    immutable
    language sql
as
$$SELECT '2026-06-14 08:37:58'::text AS version$$;

alter function postgis_scripts_build_date() owner to postgres;

